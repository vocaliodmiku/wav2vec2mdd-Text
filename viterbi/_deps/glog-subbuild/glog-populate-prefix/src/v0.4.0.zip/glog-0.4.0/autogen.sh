#!/bin/sh

set -eu

autoreconf -i
